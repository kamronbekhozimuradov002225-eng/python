# 🐍 Python Web Studio — Professional Online Python IDE & WASM Runtime

> **English & O'zbekcha Hujjatlar / Complete Documentation**

Python Web Studio represents an enterprise-grade, browser-based Python development platform powered by **Pyodide WASM Engine (Python 3.11)** and **Google Gemini 2.5 Flash AI Assistant**. It gives developers, students, and data scientists a full VS Code-like experience directly in the browser with **zero setup or installation required**.

---

## 🌟 English Overview

### Key Features
- **⚡ In-Browser Python 3.11 WASM**: Pure browser execution with full access to Python standard library, standard input (`input()`), and file I/O.
- **💻 Monaco Code Editor**: Standard VS Code editor with syntax highlighting, autocomplete, code folding, line numbers, and custom keybindings.
- **📊 Matplotlib & Graphics Support**: Native automatic rendering of Matplotlib charts (`plt.show()`) into dedicated visual tabs.
- **📦 PyPI Package Manager**: One-click dynamic installation of WASM-compiled Python packages including `numpy`, `pandas`, `matplotlib`, `scipy`, `sympy`, and `pillow`.
- **🐚 Interactive REPL Terminal**: Real-time evaluation shell for testing Python expressions and snippets instantly.
- **🤖 Gemini AI Python Assistant**: Built-in AI assistant for code explanation, automated error debugging, PEP8 refactoring, and code generation.
- **📂 Multi-file Virtual Workspace**: Create, rename, edit, and delete multiple `.py` files within the workspace.
- **🌓 Dark & Light Theme Support**: Professional VS Code Dark (`vs-dark`) and Light theme toggle.
- **📱 Fully Responsive**: Fluid adaptive layout across Mobile, Tablet, and Desktop screens.

---

## 🇺🇿 O'zbekcha Ma'lumot va Ko'rsatmalari

Python Web Studio — bu brauzerda maxsus o'rnatishlarsiz Python kodi yozish, uni bajarish va Gemini AI yordamida optimallashtirish imkonini beruvchi professional IDE.

### Asosiy Imkoniyatlar:
1. **To'liq Python 3.11 Ishchi Muhiti**: Pyodide WebAssembly texnologiyasi asosida kodingiz bevosita brauzeringizda xavfsiz va juda tez ishlaydi.
2. **Monaco Editor (VS Code)**: Kodingizni qulay va chiroyli tahrirlash uchun sintaksis bo'yash, avtomatik to'ldirish va qator raqamlari.
3. **Grafik va Matplotlib Vizualizatsiya**: `matplotlib.pyplot` yordamida chizilgan barcha grafik va diagrammalar avtomatik tarzda maxsus tabda namoyon bo'ladi.
4. **Kutubxonalar Menejeri (pip)**: NumPy, Pandas, Matplotlib kabi mashhur kutubxonalarni bir bosingda yuklab olish.
5. **Gemini AI Yordamchi**: Koddagi xatolarni avtomatik topish, izohlash va kodingizni PEP 8 standartiga moslashtirish.
6. **Moslashuvchan Dizayn**: Telefon, planshet va kompyuterlarda birdek qulay ishlaydi.

---

## 🚀 Tech Stack & Architecture

- **Frontend**: React 19, TypeScript, Tailwind CSS v4, Lucide React, Monaco Editor React, Motion
- **Runtime Engine**: Pyodide v0.26.4 WASM (WebAssembly)
- **Backend API Server**: Node.js, Express, `@google/genai` (Gemini 2.5 Flash SDK)
- **Build Tooling**: Vite 6, esbuild, tsx

---

## 🛠️ Security & Optimization Implementation

- **XSS & Injection Safeguards**: Safe text escaping and sanitization across stdout, stderr, and REPL input evaluation.
- **CSRF & Rate Limiting**: Server-side payload limits, strict JSON body parsing, and request logging.
- **Lazy AI Client Initialization**: Gemini API keys stay server-side (`GEMINI_API_KEY`) and are never exposed to the client.
- **Fallback Error Boundaries**: Graceful React component error boundary catching uncaught runtime UI exceptions.

---

## 📦 Local Development Setup

```bash
# 1. Clone the repository
git clone https://github.com/your-username/python-web-studio.git
cd python-web-studio

# 2. Install dependencies
npm install

# 3. Configure environment variables (.env)
cp .env.example .env
# Add your GEMINI_API_KEY inside .env if needed

# 4. Start local dev server (Express + Vite on http://localhost:3000)
npm run dev

# 5. Build for production
npm run build

# 6. Start production server
npm start
```

---

## 🐳 Cloud Deployment Instructions

### 1. Google Cloud Run / Docker Container
```bash
docker build -t python-web-studio .
docker run -p 3000:3000 -e GEMINI_API_KEY="your-key" python-web-studio
```

### 2. Render / Railway / Vercel
- **Render**: Connect repository and select Docker or Web Service (`npm run build` & `npm start`).
- **Railway**: Uses root `Dockerfile` or `railway.json` automatically.
- **Vercel**: Configuration included in `vercel.json`.

---

## 📄 License
MIT License — Free for commercial and non-commercial open-source use.
