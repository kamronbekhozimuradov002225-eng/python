import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

// Security & Request Logger Middleware
app.use((req: Request, res: Response, next: NextFunction) => {
  const start = Date.now();
  
  // Security Headers
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('X-XSS-Protection', '1; mode=block');

  res.on('finish', () => {
    const duration = Date.now() - start;
    const isoDate = new Date().toISOString();
    console.log(`[${isoDate}] ${req.method} ${req.originalUrl} ${res.statusCode} - ${duration}ms`);
  });

  next();
});

app.use(express.json({ limit: '10mb' }));

// Simple in-memory rate limiter for AI endpoint
const rateLimitMap = new Map<string, { count: number; resetTime: number }>();
const checkRateLimit = (ip: string): boolean => {
  const now = Date.now();
  const windowMs = 60 * 1000; // 1 minute
  const maxRequests = 30; // 30 requests per minute

  const record = rateLimitMap.get(ip);
  if (!record || now > record.resetTime) {
    rateLimitMap.set(ip, { count: 1, resetTime: now + windowMs });
    return true;
  }

  if (record.count >= maxRequests) {
    return false;
  }

  record.count++;
  return true;
};

// Lazy Gemini API initialization
let aiClient: GoogleGenAI | null = null;
function getAI() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  if (!aiClient) {
    aiClient = new GoogleGenAI({ apiKey });
  }
  return aiClient;
}

// Health check endpoint
app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    python: 'Pyodide WASM Runtime Active',
    timestamp: new Date().toISOString(),
    env: process.env.NODE_ENV || 'development'
  });
});

// Gemini AI Python Assistant endpoint
app.post('/api/ai/assistant', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const clientIp = req.ip || req.socket.remoteAddress || 'unknown';
    if (!checkRateLimit(clientIp)) {
      return res.status(429).json({ error: 'Too many requests. Please wait a minute before asking AI again.' });
    }

    const { action, code, error, prompt } = req.body;

    // Input Validation
    if (action && typeof action !== 'string') {
      return res.status(400).json({ error: 'Invalid action parameter type' });
    }

    const ai = getAI();

    if (!ai) {
      return res.status(400).json({
        error: 'Gemini API key is missing. Please configure GEMINI_API_KEY in environment variables or Settings.',
      });
    }

    let systemInstruction = "You are an expert Python programming assistant in an interactive web IDE.";
    let userPrompt = "";

    const sanitizedCode = typeof code === 'string' ? code.slice(0, 50000) : '';
    const sanitizedError = typeof error === 'string' ? error.slice(0, 10000) : '';
    const sanitizedPrompt = typeof prompt === 'string' ? prompt.slice(0, 10000) : '';

    if (action === 'explain') {
      systemInstruction += " Explain the Python code concisely with markdown, highlighting key logic, data structures, and function workflows.";
      userPrompt = `Please explain this Python code:\n\n\`\`\`python\n${sanitizedCode}\n\`\`\``;
    } else if (action === 'debug') {
      systemInstruction += " Find the cause of the Python runtime error or syntax error and provide the corrected full code with a brief explanation.";
      userPrompt = `Code:\n\`\`\`python\n${sanitizedCode}\n\`\`\`\n\nError output:\n\`\`\`\n${sanitizedError}\n\`\`\``;
    } else if (action === 'optimize') {
      systemInstruction += " Optimize this Python code for performance, readability, and Pythonic best practices (PEP 8).";
      userPrompt = `Optimize this Python code:\n\n\`\`\`python\n${sanitizedCode}\n\`\`\``;
    } else if (action === 'generate') {
      systemInstruction += " Write clean, fully-functional Python 3 code matching the user's prompt. Provide the full code block first, followed by brief explanations or usage examples.";
      userPrompt = sanitizedPrompt;
    } else {
      userPrompt = sanitizedPrompt || `Help me with this Python code:\n\`\`\`python\n${sanitizedCode}\n\`\`\``;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: userPrompt,
      config: {
        systemInstruction,
        temperature: 0.3,
      },
    });

    res.json({ response: response.text });
  } catch (err: any) {
    console.error('Gemini API Error:', err);
    res.status(500).json({ error: err.message || 'Failed to process AI request' });
  }
});

// API 404 Fallback
app.use('/api/*', (req: Request, res: Response) => {
  res.status(404).json({ error: `API route '${req.originalUrl}' not found.` });
});

// Vite Middleware for Dev / Static Files for Prod
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // Global Express Error Handler
  app.use((err: any, req: Request, res: Response, next: NextFunction) => {
    console.error('Unhandled Server Error:', err);
    res.status(500).json({ error: 'Internal Server Error', details: err.message });
  });

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Python IDE Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();

