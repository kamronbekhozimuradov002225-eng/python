import { ConsoleOutput, StdinRequest } from '../types';

declare global {
  interface Window {
    loadPyodide?: (config: any) => Promise<any>;
    pyodideInstance?: any;
  }
}

type OutputCallback = (output: Omit<ConsoleOutput, 'id' | 'timestamp'>) => void;
type StdinCallback = (request: StdinRequest) => void;

class PyodideRunner {
  private pyodide: any = null;
  private isInitializing: boolean = false;
  private initPromise: Promise<any> | null = null;

  private onOutput: OutputCallback | null = null;
  private onStdin: StdinCallback | null = null;

  public setOutputCallback(cb: OutputCallback) {
    this.onOutput = cb;
  }

  public setStdinCallback(cb: StdinCallback) {
    this.onStdin = cb;
  }

  // Load Pyodide script into DOM if not present
  private loadPyodideScript(): Promise<void> {
    return new Promise((resolve, reject) => {
      if (window.loadPyodide) {
        resolve();
        return;
      }

      const script = document.createElement('script');
      script.src = 'https://cdn.jsdelivr.net/pyodide/v0.26.4/full/pyodide.js';
      script.async = true;
      script.onload = () => resolve();
      script.onerror = () => reject(new Error('Failed to load Pyodide WASM runtime script from CDN.'));
      document.head.appendChild(script);
    });
  }

  // Initialize Pyodide engine
  public async init(onStatus?: (status: string) => void): Promise<any> {
    if (this.pyodide) return this.pyodide;
    if (this.initPromise) return this.initPromise;

    this.isInitializing = true;
    this.initPromise = (async () => {
      try {
        if (onStatus) onStatus('Loading Pyodide WASM Core (15MB)...');
        await this.loadPyodideScript();

        if (onStatus) onStatus('Initializing Python 3.11 WASM Engine...');
        this.pyodide = await window.loadPyodide!({
          indexURL: 'https://cdn.jsdelivr.net/pyodide/v0.26.4/full/',
          stdout: (text: string) => {
            if (this.onOutput && text) {
              this.onOutput({ type: 'stdout', text });
            }
          },
          stderr: (text: string) => {
            if (this.onOutput && text) {
              // Only mark as stderr traceback if it actually contains an exception/traceback
              if (
                text.includes('Traceback') ||
                text.includes('Error:') ||
                text.includes('Exception:') ||
                text.includes('SyntaxError') ||
                text.includes('TypeError') ||
                text.includes('ValueError') ||
                text.includes('NameError')
              ) {
                this.onOutput({ type: 'stderr', text });
              } else {
                // Otherwise treat as standard output / warning log
                this.onOutput({ type: 'stdout', text });
              }
            }
          },
        });

        window.pyodideInstance = this.pyodide;

        if (onStatus) onStatus('Configuring Python Stdlib & Helpers...');

        // Setup Python environment overrides (synchronous input handling & matplotlib auto-show)
        await this.pyodide.runPythonAsync(`
import sys
import io
import base64
import js
import builtins

# Synchronous input() bridge using browser prompt modal
def _custom_input(prompt=""):
    prompt_str = str(prompt) if prompt is not None else ""
    try:
        res = js.window.prompt(prompt_str if prompt_str else "Python input():")
        if res is None:
            res = ""
        # Echo prompt and entered text into stdout
        if prompt_str:
            print(f"{prompt_str}{res}")
        else:
            print(res)
        return str(res)
    except Exception:
        return ""

builtins.input = _custom_input

# Setup matplotlib figure auto-interceptor
try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    def _custom_show():
        buf = io.BytesIO()
        plt.savefig(buf, format='png', bbox_inches='tight', dpi=120)
        buf.seek(0)
        img_str = base64.b64encode(buf.read()).decode('utf-8')
        plt.close('all')
        js.window.pyodideRenderPlot("data:image/png;base64," + img_str)

    plt.show = _custom_show
except ImportError:
    pass
`);

        // Setup global window handlers for JS calls from Python
        window.pyodideRequestStdin = (promptText: string) => {
          return new Promise<string>((resolve) => {
            if (this.onStdin) {
              this.onStdin({
                prompt: promptText || 'input: ',
                resolve,
              });
            } else {
              resolve('');
            }
          });
        };

        window.pyodideRenderPlot = (base64Img: string) => {
          if (this.onOutput) {
            this.onOutput({
              type: 'matplotlib',
              text: '📊 Matplotlib Plot Rendered',
              imageData: base64Img,
            });
          }
        };

        if (onStatus) onStatus('Pyodide Engine Ready');
        return this.pyodide;
      } catch (err: any) {
        console.error('Pyodide Init Error:', err);
        throw err;
      } finally {
        this.isInitializing = false;
      }
    })();

    return this.initPromise;
  }

  // Auto-detect imports and load required packages safely
  public async loadPackagesForCode(code: string, onStatus?: (status: string) => void): Promise<void> {
    if (!this.pyodide) return;

    try {
      if (onStatus) onStatus('Analyzing imports & dependencies...');

      if (typeof this.pyodide.loadPackagesFromImports === 'function') {
        await this.pyodide.loadPackagesFromImports(code);
      } else {
        const packagesToLoad = new Set<string>();
        if (/import\s+numpy|from\s+numpy/.test(code)) packagesToLoad.add('numpy');
        if (/import\s+pandas|from\s+pandas/.test(code)) packagesToLoad.add('pandas');
        if (/import\s+matplotlib|from\s+matplotlib/.test(code)) packagesToLoad.add('matplotlib');
        if (/import\s+scipy|from\s+scipy/.test(code)) packagesToLoad.add('scipy');
        if (/import\s+sympy|from\s+sympy/.test(code)) packagesToLoad.add('sympy');

        if (packagesToLoad.size > 0) {
          await this.pyodide.loadPackage(Array.from(packagesToLoad));
        }
      }
    } catch (e) {
      console.warn('Package auto-load warning:', e);
    }
  }

  // Execute full Python code string
  public async runCode(
    code: string,
    files: { name: string; content: string }[],
    onStatus?: (status: string) => void
  ): Promise<{ executionTimeMs: number }> {
    const startTime = performance.now();
    await this.init(onStatus);

    await this.loadPackagesForCode(code, onStatus);

    // Sync all workspace files into Pyodide virtual filesystem
    const userModuleNames: string[] = [];
    for (const file of files) {
      try {
        this.pyodide.FS.writeFile(file.name, file.content);
        if (file.name.endsWith('.py')) {
          userModuleNames.push(file.name.replace(/\.py$/, ''));
        }
      } catch (e) {
        console.warn(`Could not write virtual file ${file.name}:`, e);
      }
    }

    // Invalidate user modules in sys.modules so imports are always fresh
    try {
      await this.pyodide.runPythonAsync(`
import sys
for _mod in ${JSON.stringify(userModuleNames)}:
    if _mod in sys.modules and _mod != '__main__':
        del sys.modules[_mod]
`);
    } catch (e) {
      // Ignored
    }

    if (onStatus) onStatus('Running Python code...');

    try {
      await this.pyodide.runPythonAsync(code);
    } catch (err: any) {
      const errorMsg = err.message || String(err);
      if (this.onOutput) {
        this.onOutput({
          type: 'stderr',
          text: errorMsg,
        });
      }
    }

    const endTime = performance.now();
    return { executionTimeMs: Math.round(endTime - startTime) };
  }

  // Execute interactive REPL expression/statement
  public async runREPL(command: string): Promise<string> {
    await this.init();

    let capturedOutputs: string[] = [];
    const previousOnOutput = this.onOutput;

    this.onOutput = (out) => {
      if (out.type === 'stdout' && out.text) {
        capturedOutputs.push(out.text);
      }
      if (previousOnOutput) previousOnOutput(out);
    };

    try {
      const result = await this.pyodide.runPythonAsync(command);
      this.onOutput = previousOnOutput;

      const stdoutJoined = capturedOutputs.join('').trim();
      if (result !== undefined && result !== null && String(result) !== 'None') {
        return stdoutJoined ? `${stdoutJoined}\n${String(result)}` : String(result);
      }
      return stdoutJoined;
    } catch (err: any) {
      this.onOutput = previousOnOutput;
      throw err;
    }
  }

  // Load a single named package manually via Pyodide
  public async installPackage(packageName: string): Promise<void> {
    await this.init();
    await this.pyodide.loadPackage(packageName);
  }
}

declare global {
  interface Window {
    pyodideRequestStdin?: (prompt: string) => Promise<string>;
    pyodideRenderPlot?: (base64Img: string) => void;
  }
}

export const pyodideRunner = new PyodideRunner();
