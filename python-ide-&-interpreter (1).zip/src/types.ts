export interface PythonFile {
  id: string;
  name: string;
  content: string;
  isMain?: boolean;
  createdAt: number;
}

export type ConsoleOutputType =
  | 'stdout'
  | 'stderr'
  | 'system'
  | 'input-prompt'
  | 'input-result'
  | 'matplotlib'
  | 'turtle'
  | 'error';

export interface ConsoleOutput {
  id: string;
  type: ConsoleOutputType;
  text: string;
  timestamp: string;
  imageData?: string; // base64 PNG for plots
}

export interface PythonPackage {
  name: string;
  description: string;
  status: 'available' | 'installing' | 'installed' | 'error';
  version?: string;
  category: 'Data Science' | 'Visualization' | 'Math & Science' | 'Utilities';
}

export interface CodeExample {
  id: string;
  title: string;
  category: 'Basics' | 'Data Structures' | 'OOP' | 'Algorithms' | 'Data Science' | 'Visualization' | 'Turtle & Games';
  description: string;
  code: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
}

export type IDETheme = 'vs-dark' | 'light' | 'hc-black';

export interface PyodideState {
  isLoaded: boolean;
  isLoading: boolean;
  isExecuting: boolean;
  error: string | null;
  statusMessage: string;
}

export interface StdinRequest {
  prompt: string;
  resolve: (input: string) => void;
}
