import { CodeExample } from '../types';

export const PYTHON_EXAMPLES: CodeExample[] = [
  {
    id: 'hello-world',
    title: 'Hello, Python!',
    category: 'Basics',
    difficulty: 'Beginner',
    description: 'Basic print statements, string formatting, and mathematical operations in Python 3.',
    code: `# Welcome to Python IDE & Interactive Interpreter!
# Run this code by clicking the "Run Code" button (or press Ctrl + Enter)

import sys
import platform

print("=" * 40)
print("🐍 Hello World from Python!")
print(f"Python Version: {platform.python_version()}")
print(f"Platform: {sys.platform}")
print("=" * 40)

# Variables and operations
user_name = "Developer"
year = 2026
languages = ["Python", "JavaScript", "TypeScript", "C++", "Rust"]

print(f"\\nWelcome back, {user_name}! It's {year}.")
print("Popular languages:", ", ".join(languages))

# Quick math calculation
radius = 7.5
pi = 3.14159265
area = pi * (radius ** 2)
print(f"\\nCircle Area with radius {radius} = {area:.2f}")
`,
  },
  {
    id: 'interactive-input',
    title: 'Interactive User Stdin & Calculator',
    category: 'Basics',
    difficulty: 'Beginner',
    description: 'Demonstrates input() handling in Python with interactive console input prompts.',
    code: `# Interactive Console Stdin Demo
# When input() is called, type your answer in the Console input field below!

print("🧮 Interactive Python Calculator")
print("-" * 35)

try:
    num1_str = input("Enter first number: ")
    num2_str = input("Enter second number: ")
    
    num1 = float(num1_str)
    num2 = float(num2_str)
    
    print("\\nResults:")
    print(f"  Addition       ({num1} + {num2}) = {num1 + num2}")
    print(f"  Subtraction    ({num1} - {num2}) = {num1 - num2}")
    print(f"  Multiplication ({num1} * {num2}) = {num1 * num2}")
    if num2 != 0:
        print(f"  Division       ({num1} / {num2}) = {num1 / num2:.4f}")
        print(f"  Power          ({num1} ^ {num2}) = {num1 ** num2:.2f}")
    else:
        print("  Division       : Cannot divide by zero!")

except ValueError:
    print("❌ Error: Please enter valid numbers!")
`,
  },
  {
    id: 'data-structures',
    title: 'Lists, Dicts & List Comprehensions',
    category: 'Data Structures',
    difficulty: 'Beginner',
    description: 'Master list comprehensions, dictionary operations, and sorting in Python.',
    code: `# Python Data Structures Masterclass

# 1. List Comprehension
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
squares = [x**2 for x in numbers]
even_squares = [x**2 for x in numbers if x % 2 == 0]

print("Original Numbers:", numbers)
print("Squares         :", squares)
print("Even Squares    :", even_squares)

# 2. Dictionaries & Nested Operations
student_grades = {
    "Alice": [88, 92, 95],
    "Bob": [75, 80, 85],
    "Charlie": [90, 91, 93],
    "Diana": [98, 97, 100]
}

print("\\n--- Student Performance ---")
averages = {name: sum(grades)/len(grades) for name, grades in student_grades.items()}

for name, avg in sorted(averages.items(), key=lambda x: x[1], reverse=True):
    status = "🏆 Distinction" if avg >= 90 else "✅ Passed"
    print(f"  {name:<10}: {avg:.1f}% -> {status}")
`,
  },
  {
    id: 'oop-bank-account',
    title: 'Object-Oriented Bank Account',
    category: 'OOP',
    difficulty: 'Intermediate',
    description: 'Classes, encapsulation, private attributes, inheritance, and custom exception handling.',
    code: `# Object-Oriented Programming (OOP) in Python

class InsufficientFundsError(Exception):
    """Custom Exception for overdrafts"""
    pass

class BankAccount:
    def __init__(self, owner: str, initial_balance: float = 0.0):
        self.owner = owner
        self._balance = max(0.0, initial_balance) # Encapsulated balance
        self.transactions = []

    @property
    def balance(self) -> float:
        return self._balance

    def deposit(self, amount: float):
        if amount <= 0:
            raise ValueError("Deposit amount must be positive!")
        self._balance += amount
        self.transactions.append(f"Deposited: +\${amount:.2f}")
        print(f"💵 [Deposit] \${amount:.2f} | New Balance: \${self._balance:.2f}")

    def withdraw(self, amount: float):
        if amount > self._balance:
            raise InsufficientFundsError(f"Overdraft! Cannot withdraw \${amount:.2f} with balance \${self._balance:.2f}")
        self._balance -= amount
        self.transactions.append(f"Withdrew: -\${amount:.2f}")
        print(f"💸 [Withdraw] \${amount:.2f} | New Balance: \${self._balance:.2f}")

    def statement(self):
        print(f"\\n--- Account Statement for {self.owner} ---")
        for idx, tx in enumerate(self.transactions, 1):
            print(f"  {idx}. {tx}")
        print(f"Total Current Balance: \${self._balance:.2f}\\n")


# Testing the OOP class
account = BankAccount("Sardor Bek", 500.0)
account.deposit(250.0)
account.withdraw(120.0)

try:
    account.withdraw(1000.0) # Will trigger custom exception
except InsufficientFundsError as e:
    print(f"❌ Transaction Failed: {e}")

account.statement()
`,
  },
  {
    id: 'algorithms-fibonacci',
    title: 'Fibonacci & Prime Sieve (Algorithms)',
    category: 'Algorithms',
    difficulty: 'Intermediate',
    description: 'Comparison of recursion, memoization (DP), dynamic generators, and Sieve of Eratosthenes.',
    code: `# Advanced Algorithms in Python

import time

# 1. Fibonacci with Memoization (Dynamic Programming)
def fibonacci_dp(n: int, memo={}) -> int:
    if n in memo:
        return memo[n]
    if n <= 1:
        return n
    memo[n] = fibonacci_dp(n - 1, memo) + fibonacci_dp(n - 2, memo)
    return memo[n]

# 2. Sieve of Eratosthenes for Prime Numbers
def find_primes_up_to(limit: int) -> list:
    is_prime = [True] * (limit + 1)
    is_prime[0] = is_prime[1] = False
    
    for p in range(2, int(limit**0.5) + 1):
        if is_prime[p]:
            for i in range(p * p, limit + 1, p):
                is_prime[i] = False
                
    return [i for i in range(limit + 1) if is_prime[i]]

print("--- Algorithm Tests ---")
start = time.time()
fib_50 = fibonacci_dp(50)
print(f"50th Fibonacci Number : {fib_50:,}")

primes = find_primes_up_to(200)
print(f"Primes up to 200 ({len(primes)} total):")
print(primes[:20], "... [and more]")
`,
  },
  {
    id: 'matplotlib-charts',
    title: 'Matplotlib Data Visualization (Plots)',
    category: 'Visualization',
    difficulty: 'Intermediate',
    description: 'Generates trigonometric graphs and renders visual PNG charts directly in output console.',
    code: `# Matplotlib Trigonometric Visualization
# Automatically renders the generated plot in the Plots panel!

import matplotlib.pyplot as plt
import numpy as np

# Generate x values
x = np.linspace(0, 4 * np.pi, 200)
y_sin = np.sin(x)
y_cos = np.cos(x)
y_damp = np.sin(x) * np.exp(-x / 5)

# Create figure and axis
plt.figure(figsize=(9, 5), dpi=100)
plt.style.use('seaborn-v0_8-darkgrid' if 'seaborn-v0_8-darkgrid' in plt.style.available else 'default')

plt.plot(x, y_sin, label='Sin(x)', color='#3b82f6', linewidth=2.5)
plt.plot(x, y_cos, label='Cos(x)', color='#ef4444', linewidth=2.5, linestyle='--')
plt.plot(x, y_damp, label='Damped Sin(x)', color='#10b981', linewidth=2)

plt.title('Trigonometric Functions & Damping in Python', fontsize=14, fontweight='bold', pad=15)
plt.xlabel('Angle (radians)', fontsize=11)
plt.ylabel('Amplitude', fontsize=11)
plt.axhline(0, color='black', linewidth=0.8, linestyle=':')
plt.legend(loc='upper right', frameon=True)
plt.grid(True, alpha=0.3)
plt.tight_layout()

# Display plot in the IDE Output Window!
plt.show()
print("📊 Plot generated successfully! Switch to the 'Plots & Graphics' tab or view above.")
`,
  },
  {
    id: 'pandas-analysis',
    title: 'Data Analysis with Pandas & NumPy',
    category: 'Data Science',
    difficulty: 'Intermediate',
    description: 'Create DataFrames, clean data, group by categories, and compute summary metrics.',
    code: `# Data Science with Pandas & NumPy

import pandas as pd
import numpy as np

# Set random seed for reproducibility
np.random.seed(42)

# Generate mock sales data
cities = ["Tashkent", "Samarkand", "Bukhara", "Andijan"]
products = ["Laptop", "Smartphone", "Tablet", "Smartwatch"]

dates = pd.date_range(start="2026-01-01", periods=10, freq="D")

data = {
    "Date": np.random.choice(dates, size=20),
    "City": np.random.choice(cities, size=20),
    "Product": np.random.choice(products, size=20),
    "Quantity": np.random.randint(1, 10, size=20),
    "UnitPrice": np.random.choice([150, 300, 750, 1200], size=20)
}

df = pd.DataFrame(data)
df["TotalRevenue"] = df["Quantity"] * df["UnitPrice"]

print("=== Raw Sales Dataset (Top 5 Rows) ===")
print(df.head())

print("\\n=== Revenue Summary by City ===")
city_summary = df.groupby("City")["TotalRevenue"].agg(["sum", "mean", "count"]).rename(columns={"sum": "Total (\$)", "mean": "Average (\$)", "count": "Orders"})
print(city_summary)

print("\\n=== Top Selling Product ===")
top_product = df.groupby("Product")["Quantity"].sum().sort_values(ascending=False)
print(top_product)
`,
  },
  {
    id: 'turtle-graphics',
    title: 'Python Turtle Graphics Spiral',
    category: 'Turtle & Games',
    difficulty: 'Intermediate',
    description: 'Draw geometric patterns and colored spiral stars using Pyodide Canvas emulation.',
    code: `# Python Turtle Visual Art
# Runs smooth canvas rendering in the IDE

import turtle

# Setup screen
screen = turtle.Screen()
screen.bgcolor("#0f172a") # Dark Slate theme
screen.title("Python Turtle Color Spiral")

t = turtle.Turtle()
t.speed(0) # Fastest
t.width(2)

colors = ["#3b82f6", "#8b5cf6", "#ec4899", "#f43f5e", "#eab308", "#10b981"]

print("🎨 Rendering Turtle Graphics Canvas...")

for i in range(120):
    t.pencolor(colors[i % len(colors)])
    t.forward(i * 3)
    t.right(59)

print("✨ Turtle Graphic Drawing Complete!")
`,
  },
  {
    id: 'guess-number-game',
    title: 'Guess the Number Mini-Game',
    category: 'Turtle & Games',
    difficulty: 'Beginner',
    description: 'Fun interactive CLI game with secret numbers, attempt tracking, and score hints.',
    code: `# Guess the Secret Number Game!

import random

secret_number = random.randint(1, 100)
attempts = 0
max_attempts = 7

print("🎯 Welcome to the Number Guessing Challenge!")
print(f"I'm thinking of a secret number between 1 and 100.")
print(f"You have {max_attempts} attempts to guess it correctly!\\n")

while attempts < max_attempts:
    attempts += 1
    try:
        user_input = input(f"Attempt {attempts}/{max_attempts} - Enter your guess: ")
        guess = int(user_input)
        
        if guess < secret_number:
            print("📈 Higher! Try a larger number.")
        elif guess > secret_number:
            print("📉 Lower! Try a smaller number.")
        else:
            print(f"\\n🎉 CONGRATULATIONS! You found secret number {secret_number} in {attempts} tries!")
            break
            
    except ValueError:
        print("⚠️ Invalid input! Please enter a whole integer.")

if attempts >= max_attempts and guess != secret_number:
    print(f"\\n💥 Game Over! The secret number was {secret_number}. Better luck next time!")
`,
  }
];
