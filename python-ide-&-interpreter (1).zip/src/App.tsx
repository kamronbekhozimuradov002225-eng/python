import React, { useState, useEffect, useCallback } from 'react';
import {
  PythonFile,
  ConsoleOutput,
  IDETheme,
  PyodideState,
  StdinRequest,
  CodeExample
} from './types';
import { PYTHON_EXAMPLES } from './data/examples';
import { pyodideRunner } from './lib/pyodideRunner';

import { Navbar } from './components/Navbar';
import { FileExplorer } from './components/FileExplorer';
import { CodeEditor } from './components/CodeEditor';
import { OutputConsole } from './components/OutputConsole';
import { REPLTerminal } from './components/REPLTerminal';
import { AIAssistantDrawer } from './components/AIAssistantDrawer';
import { PackageManagerModal } from './components/PackageManagerModal';
import { ShortcutsModal } from './components/ShortcutsModal';

const INITIAL_FILES: PythonFile[] = [
  {
    id: 'main-py',
    name: 'main.py',
    content: PYTHON_EXAMPLES[0].code,
    isMain: true,
    createdAt: Date.now(),
  },
  {
    id: 'helpers-py',
    name: 'helpers.py',
    content: `# Helper functions module
def calculate_factorial(n: int) -> int:
    """Returns factorial of n"""
    if n <= 1:
        return 1
    return n * calculate_factorial(n - 1)

def format_currency(amount: float) -> str:
    """Formats float to currency string"""
    return f"\${amount:,.2f}"
`,
    createdAt: Date.now() + 1,
  },
];

export default function App() {
  const [files, setFiles] = useState<PythonFile[]>(() => {
    const saved = localStorage.getItem('python_ide_files');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { }
    }
    return INITIAL_FILES;
  });

  const [activeFileId, setActiveFileId] = useState<string>(() => files[0]?.id || 'main-py');
  const [theme, setTheme] = useState<IDETheme>('vs-dark');
  const [activeTab, setActiveTab] = useState<'editor' | 'repl'>('editor');

  const [consoleOutputs, setConsoleOutputs] = useState<ConsoleOutput[]>([]);
  const [stdinRequest, setStdinRequest] = useState<StdinRequest | null>(null);
  const [executionTimeMs, setExecutionTimeMs] = useState<number | null>(null);

  const [pyodideState, setPyodideState] = useState<PyodideState>({
    isLoaded: false,
    isLoading: false,
    isExecuting: false,
    error: null,
    statusMessage: 'Pyodide WASM Engine Ready',
  });

  const [isAiDrawerOpen, setIsAiDrawerOpen] = useState<boolean>(false);
  const [isPackageManagerOpen, setIsPackageManagerOpen] = useState<boolean>(false);
  const [isShortcutsOpen, setIsShortcutsOpen] = useState<boolean>(false);

  // Save files to localStorage
  useEffect(() => {
    localStorage.setItem('python_ide_files', JSON.stringify(files));
  }, [files]);

  const activeFile = files.find((f) => f.id === activeFileId) || files[0];

  // Set up output callbacks
  useEffect(() => {
    pyodideRunner.setOutputCallback((out) => {
      setConsoleOutputs((prev) => [
        ...prev,
        {
          id: String(Date.now()) + Math.random().toString(36).substring(2, 5),
          timestamp: new Date().toLocaleTimeString(),
          ...out,
        },
      ]);
    });

    pyodideRunner.setStdinCallback((req) => {
      setStdinRequest(req);
      setConsoleOutputs((prev) => [
        ...prev,
        {
          id: String(Date.now()),
          type: 'input-prompt',
          text: req.prompt || 'input: ',
          timestamp: new Date().toLocaleTimeString(),
        },
      ]);
    });
  }, []);

  // Pre-load Pyodide engine lazily in background
  useEffect(() => {
    pyodideRunner
      .init((status) => {
        setPyodideState((prev) => ({ ...prev, statusMessage: status }));
      })
      .then(() => {
        setPyodideState((prev) => ({
          ...prev,
          isLoaded: true,
          statusMessage: 'Pyodide Ready',
        }));
      })
      .catch((err) => {
        setPyodideState((prev) => ({
          ...prev,
          error: String(err),
          statusMessage: 'Failed to load Pyodide',
        }));
      });
  }, []);

  const handleRunCode = async () => {
    if (!activeFile) return;

    setConsoleOutputs([]);
    setStdinRequest(null);
    setExecutionTimeMs(null);

    setPyodideState((prev) => ({
      ...prev,
      isExecuting: true,
      statusMessage: 'Executing Python Code...',
    }));

    // Log system start
    setConsoleOutputs([
      {
        id: 'start-log',
        type: 'system',
        text: `>>> Running ${activeFile.name}...`,
        timestamp: new Date().toLocaleTimeString(),
      },
    ]);

    try {
      const result = await pyodideRunner.runCode(
        activeFile.content,
        files.map((f) => ({ name: f.name, content: f.content })),
        (status) => {
          setPyodideState((prev) => ({ ...prev, statusMessage: status }));
        }
      );

      setExecutionTimeMs(result.executionTimeMs);
      setConsoleOutputs((prev) => [
        ...prev,
        {
          id: 'end-log',
          type: 'system',
          text: `>>> Execution Finished in ${result.executionTimeMs} ms`,
          timestamp: new Date().toLocaleTimeString(),
        },
      ]);
    } catch (err: any) {
      setConsoleOutputs((prev) => [
        ...prev,
        {
          id: String(Date.now()),
          type: 'stderr',
          text: err.message || String(err),
          timestamp: new Date().toLocaleTimeString(),
        },
      ]);
    } finally {
      setPyodideState((prev) => ({
        ...prev,
        isExecuting: false,
        statusMessage: 'Pyodide Ready',
      }));
    }
  };

  const handleSendStdin = (inputVal: string) => {
    if (stdinRequest) {
      setConsoleOutputs((prev) => [
        ...prev,
        {
          id: String(Date.now()),
          type: 'input-result',
          text: inputVal,
          timestamp: new Date().toLocaleTimeString(),
        },
      ]);
      stdinRequest.resolve(inputVal);
      setStdinRequest(null);
    }
  };

  const handleCodeChange = (newVal: string) => {
    setFiles((prev) =>
      prev.map((f) => (f.id === activeFileId ? { ...f, content: newVal } : f))
    );
  };

  const handleCreateFile = (name: string) => {
    const newFile: PythonFile = {
      id: 'file-' + Date.now(),
      name,
      content: `# ${name}\n`,
      createdAt: Date.now(),
    };
    setFiles((prev) => [...prev, newFile]);
    setActiveFileId(newFile.id);
  };

  const handleDeleteFile = (id: string) => {
    if (files.length <= 1) return;
    setFiles((prev) => prev.filter((f) => f.id !== id));
    if (activeFileId === id) {
      const remaining = files.filter((f) => f.id !== id);
      setActiveFileId(remaining[0].id);
    }
  };

  const handleRenameFile = (id: string, newName: string) => {
    setFiles((prev) =>
      prev.map((f) => (f.id === id ? { ...f, name: newName } : f))
    );
  };

  const handleUploadFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      const uploadedFile: PythonFile = {
        id: 'file-' + Date.now(),
        name: file.name,
        content: content || '',
        createdAt: Date.now(),
      };
      setFiles((prev) => [...prev, uploadedFile]);
      setActiveFileId(uploadedFile.id);
    };
    reader.readAsText(file);
  };

  const handleDownloadFile = (file: PythonFile) => {
    const blob = new Blob([file.content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = file.name;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleSelectExample = (example: CodeExample) => {
    setFiles((prev) =>
      prev.map((f) => (f.id === activeFileId ? { ...f, content: example.code } : f))
    );
  };

  const latestError = consoleOutputs.find((o) => o.type === 'stderr')?.text;

  return (
    <div className="flex flex-col h-screen w-screen bg-[#1e1e1e] text-[#cccccc] overflow-hidden font-sans">
      {/* Top Navigation Bar */}
      <Navbar
        pyodideState={pyodideState}
        onRunCode={handleRunCode}
        onStopExecution={() => {
          setPyodideState((prev) => ({ ...prev, isExecuting: false, statusMessage: 'Execution Halted' }));
        }}
        theme={theme}
        onThemeChange={setTheme}
        onSelectExample={handleSelectExample}
        onOpenPackageManager={() => setIsPackageManagerOpen(true)}
        onOpenShortcuts={() => setIsShortcutsOpen(true)}
        isAiDrawerOpen={isAiDrawerOpen}
        onToggleAiDrawer={() => setIsAiDrawerOpen(!isAiDrawerOpen)}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onCreateFile={handleCreateFile}
      />

      {/* Main IDE Workspace (Split Panels) */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* File Explorer Sidebar */}
        <FileExplorer
          files={files}
          activeFileId={activeFileId}
          onSelectFile={setActiveFileId}
          onCreateFile={handleCreateFile}
          onDeleteFile={handleDeleteFile}
          onRenameFile={handleRenameFile}
          onUploadFile={handleUploadFile}
          onDownloadFile={handleDownloadFile}
        />

        {/* Center Canvas: Editor or REPL */}
        <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
          {activeTab === 'editor' ? (
            <>
              {/* Code Editor */}
              <CodeEditor
                value={activeFile?.content || ''}
                onChange={handleCodeChange}
                theme={theme}
                onRunCode={handleRunCode}
                fileName={activeFile?.name || 'main.py'}
                files={files}
                activeFileId={activeFileId}
                onSelectFile={setActiveFileId}
                onCreateFile={handleCreateFile}
                onDeleteFile={handleDeleteFile}
              />

              {/* Bottom Output Terminal */}
              <OutputConsole
                outputs={consoleOutputs}
                onClearOutputs={() => setConsoleOutputs([])}
                stdinRequest={stdinRequest}
                onSendStdin={handleSendStdin}
                executionTimeMs={executionTimeMs}
                isExecuting={pyodideState.isExecuting}
              />
            </>
          ) : (
            /* Interactive REPL Terminal */
            <REPLTerminal />
          )}
        </div>

        {/* Right Drawer: Gemini AI Assistant */}
        <AIAssistantDrawer
          isOpen={isAiDrawerOpen}
          onClose={() => setIsAiDrawerOpen(false)}
          code={activeFile?.content || ''}
          errorLog={latestError}
          onApplyCode={(newCode) => handleCodeChange(newCode)}
        />
      </div>

      {/* VS Code Signature Blue Status Bar */}
      <footer className="h-6 bg-[#007acc] text-white flex items-center justify-between px-3 text-[11px] select-none shrink-0 font-mono">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1 hover:bg-white/10 px-1 py-0.5 rounded cursor-pointer">
            <span></span>
            <span>main*</span>
          </span>
          <span className="flex items-center gap-1 hover:bg-white/10 px-1 py-0.5 rounded cursor-pointer">
            <span>0 ⊗</span>
            <span>0 △</span>
          </span>
          <span className="hidden sm:inline-block opacity-90">
            {pyodideState.isLoaded ? 'Pyodide WASM Engine: Active' : 'Loading Pyodide...'}
          </span>
        </div>

        <div className="flex items-center gap-3">
          <span className="hover:bg-white/10 px-1 py-0.5 rounded cursor-pointer">
            Ln {activeFile?.content ? activeFile.content.split('\n').length : 1}, Col 1
          </span>
          <span className="hidden sm:inline-block hover:bg-white/10 px-1 py-0.5 rounded cursor-pointer">
            Spaces: 4
          </span>
          <span className="hidden md:inline-block hover:bg-white/10 px-1 py-0.5 rounded cursor-pointer">
            UTF-8
          </span>
          <span className="hover:bg-white/10 px-1 py-0.5 rounded cursor-pointer font-bold">
            Python 3.11 WASM
          </span>
        </div>
      </footer>

      {/* Package Manager Modal */}
      <PackageManagerModal
        isOpen={isPackageManagerOpen}
        onClose={() => setIsPackageManagerOpen(false)}
      />

      {/* Keyboard Shortcuts Modal */}
      <ShortcutsModal
        isOpen={isShortcutsOpen}
        onClose={() => setIsShortcutsOpen(false)}
      />
    </div>
  );
}
