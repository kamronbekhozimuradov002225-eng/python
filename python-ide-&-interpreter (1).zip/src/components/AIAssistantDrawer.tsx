import React, { useState } from 'react';
import {
  Sparkles,
  X,
  Bug,
  HelpCircle,
  Zap,
  Code,
  Send,
  Check,
  Copy,
  Loader2,
  Wand2
} from 'lucide-react';
import Markdown from 'react-markdown';

interface AIAssistantDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  code: string;
  errorLog?: string;
  onApplyCode: (newCode: string) => void;
}

export const AIAssistantDrawer: React.FC<AIAssistantDrawerProps> = ({
  isOpen,
  onClose,
  code,
  errorLog,
  onApplyCode,
}) => {
  const [prompt, setPrompt] = useState('');
  const [response, setResponse] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleAIAction = async (action: 'explain' | 'debug' | 'optimize' | 'generate', customPrompt?: string) => {
    setIsLoading(true);
    setResponse(null);

    try {
      const res = await fetch('/api/ai/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action,
          code,
          error: errorLog || '',
          prompt: customPrompt || prompt,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to communicate with AI Assistant');
      }

      setResponse(data.response);
    } catch (err: any) {
      setResponse(`❌ **Error**: ${err.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;
    handleAIAction('generate', prompt);
  };

  // Extract code blocks from AI response to offer 1-click Apply Code
  const extractCode = (markdownText: string): string | null => {
    const match = markdownText.match(/```python\s*([\s\S]*?)```/) || markdownText.match(/```\s*([\s\S]*?)```/);
    return match ? match[1].trim() : null;
  };

  const extractedCode = response ? extractCode(response) : null;

  return (
    <aside className="w-80 md:w-96 bg-[#252526] border-l border-[#2b2b2b] flex flex-col h-full text-[#cccccc] select-text shrink-0 z-20 shadow-2xl font-sans">
      {/* Drawer Header */}
      <div className="p-3 border-b border-[#2b2b2b] flex items-center justify-between bg-[#1f1f1f]">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-purple-900/50 border border-purple-700/60 rounded-lg">
            <Sparkles className="w-4 h-4 text-purple-400 animate-pulse" />
          </div>
          <div>
            <h3 className="font-semibold text-xs text-white">Gemini Python AI Assistant</h3>
            <p className="text-[10px] text-purple-300">Smart Code Fixer, Explainer & Refactoring</p>
          </div>
        </div>

        <button
          onClick={onClose}
          className="p-1 text-[#aaaaaa] hover:text-white hover:bg-[#333333] rounded transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Quick AI Presets */}
      <div className="p-3 border-b border-[#2b2b2b] bg-[#252526] flex flex-col gap-2">
        <span className="text-[11px] font-semibold text-[#888888] uppercase tracking-wider">
          Quick AI Actions
        </span>

        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => handleAIAction('explain')}
            disabled={isLoading || !code.trim()}
            className="flex items-center justify-center gap-1.5 px-3 py-2 bg-[#2d2d2d] hover:bg-[#383838] disabled:opacity-40 text-[#cccccc] border border-[#3c3c3c] rounded text-xs transition-all font-medium"
          >
            <HelpCircle className="w-3.5 h-3.5 text-[#3794ff]" />
            <span>Explain Code</span>
          </button>

          <button
            onClick={() => handleAIAction('debug')}
            disabled={isLoading || !code.trim()}
            className="flex items-center justify-center gap-1.5 px-3 py-2 bg-[#2d2d2d] hover:bg-[#383838] disabled:opacity-40 text-[#cccccc] border border-[#3c3c3c] rounded text-xs transition-all font-medium"
          >
            <Bug className="w-3.5 h-3.5 text-rose-400" />
            <span>Fix Errors</span>
          </button>

          <button
            onClick={() => handleAIAction('optimize')}
            disabled={isLoading || !code.trim()}
            className="flex items-center justify-center gap-1.5 px-3 py-2 bg-[#2d2d2d] hover:bg-[#383838] disabled:opacity-40 text-[#cccccc] border border-[#3c3c3c] rounded text-xs transition-all font-medium"
          >
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span>Optimize Code</span>
          </button>

          <button
            onClick={() => handleAIAction('generate', 'Write a clean Python script to demonstrate sorting algorithms and data manipulation.')}
            disabled={isLoading}
            className="flex items-center justify-center gap-1.5 px-3 py-2 bg-[#2d2d2d] hover:bg-[#383838] disabled:opacity-40 text-[#cccccc] border border-[#3c3c3c] rounded text-xs transition-all font-medium"
          >
            <Wand2 className="w-3.5 h-3.5 text-purple-400" />
            <span>Generate Demo</span>
          </button>
        </div>
      </div>

      {/* Response Display Area */}
      <div className="flex-1 overflow-y-auto p-4 bg-[#1e1e1e] font-sans text-xs space-y-3">
        {isLoading && (
          <div className="flex flex-col items-center justify-center py-12 gap-3 text-purple-300">
            <Loader2 className="w-8 h-8 animate-spin text-purple-400" />
            <p className="text-xs font-medium">Gemini AI is analyzing your Python code...</p>
          </div>
        )}

        {!isLoading && !response && (
          <div className="text-center text-[#666666] py-12 space-y-2">
            <Sparkles className="w-8 h-8 mx-auto text-purple-900 stroke-1" />
            <p className="text-xs text-[#aaaaaa] font-medium">How can I assist your Python code today?</p>
            <p className="text-[11px] text-[#777777] max-w-xs mx-auto">
              Select an action above or type a prompt below to get instant explanation, debugging, or code refactoring.
            </p>
          </div>
        )}

        {!isLoading && response && (
          <div className="space-y-3">
            <div className="p-3 bg-[#252526] border border-[#333333] rounded text-[#cccccc] leading-relaxed overflow-x-auto">
              <Markdown>{response}</Markdown>
            </div>

            {/* If AI provided a code snippet, offer 1-click Apply */}
            {extractedCode && (
              <button
                onClick={() => onApplyCode(extractedCode)}
                className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-[#2ea043] hover:bg-[#3fb950] text-white font-semibold rounded shadow-lg transition-all text-xs"
              >
                <Code className="w-4 h-4" />
                <span>Apply AI Fix to Editor</span>
              </button>
            )}
          </div>
        )}
      </div>

      {/* Custom Prompt Input */}
      <form onSubmit={handleCustomSubmit} className="p-3 bg-[#252526] border-t border-[#2b2b2b] flex gap-2">
        <input
          type="text"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="Ask AI anything about Python..."
          disabled={isLoading}
          className="flex-1 bg-[#1e1e1e] border border-[#444444] text-white rounded px-3 py-1.5 text-xs outline-none focus:border-purple-500"
        />
        <button
          type="submit"
          disabled={isLoading || !prompt.trim()}
          className="px-3 py-1.5 bg-purple-600 hover:bg-purple-500 disabled:opacity-40 text-white font-semibold rounded text-xs transition-all flex items-center gap-1"
        >
          <Send className="w-3.5 h-3.5" />
        </button>
      </form>
    </aside>
  );
};
