import React, { useRef, useState } from 'react';
import Editor, { OnMount } from '@monaco-editor/react';
import { ZoomIn, ZoomOut, Copy, Check, Plus, X, FileCode } from 'lucide-react';
import { IDETheme, PythonFile } from '../types';

interface CodeEditorProps {
  value: string;
  onChange: (value: string) => void;
  theme: IDETheme;
  onRunCode: () => void;
  fileName: string;
  files?: PythonFile[];
  activeFileId?: string;
  onSelectFile?: (id: string) => void;
  onCreateFile?: (name: string) => void;
  onDeleteFile?: (id: string) => void;
}

export const CodeEditor: React.FC<CodeEditorProps> = ({
  value,
  onChange,
  theme,
  onRunCode,
  fileName,
  files = [],
  activeFileId,
  onSelectFile,
  onCreateFile,
  onDeleteFile,
}) => {
  const [fontSize, setFontSize] = useState<number>(14);
  const [copied, setCopied] = useState<boolean>(false);
  const [isCreatingNew, setIsCreatingNew] = useState<boolean>(false);
  const [newTabName, setNewTabName] = useState<string>('');
  const editorRef = useRef<any>(null);

  const handleEditorDidMount: OnMount = (editor, monaco) => {
    editorRef.current = editor;

    // Register Ctrl + Enter shortcut to run code
    editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.Enter, () => {
      onRunCode();
    });

    // Configure tab size = 4 spaces for Python PEP 8
    editor.getModel()?.updateOptions({ tabSize: 4, insertSpaces: true });
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(value);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCreateNewTabSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    let name = newTabName.trim();
    if (!name) {
      // Auto generate filename script_N.py if empty
      const pyCount = files.length;
      name = `script_${pyCount}.py`;
    } else if (!name.endsWith('.py')) {
      name += '.py';
    }
    if (onCreateFile) {
      onCreateFile(name);
    }
    setNewTabName('');
    setIsCreatingNew(false);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#1e1e1e] overflow-hidden relative font-sans">
      {/* Editor Sub-Header bar / Tab Header */}
      <div className="h-9 bg-[#252526] border-b border-[#2b2b2b] flex items-center justify-between px-2 text-xs text-[#aaaaaa] select-none shrink-0 overflow-x-auto">
        {/* Left: Tab list with '+' create new file button */}
        <div className="flex items-center gap-1 overflow-x-auto max-w-[80%] py-0.5">
          {files.length > 0 ? (
            files.map((file) => {
              const isActive = file.id === activeFileId || file.name === fileName;
              return (
                <div
                  key={file.id}
                  onClick={() => onSelectFile && onSelectFile(file.id)}
                  className={`group flex items-center gap-1.5 px-3 py-1 font-mono text-[12px] cursor-pointer rounded-t border-t-2 transition-all ${
                    isActive
                      ? 'bg-[#1e1e1e] text-white border-[#007acc] font-medium shadow'
                      : 'bg-[#2d2d2d] hover:bg-[#333333] text-[#888888] hover:text-[#cccccc] border-transparent'
                  }`}
                >
                  <span className="text-[#3794ff]">py</span>
                  <span className="truncate max-w-32">{file.name}</span>
                  {files.length > 1 && onDeleteFile && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteFile(file.id);
                      }}
                      className="p-0.5 hover:bg-[#383838] hover:text-rose-400 rounded transition-colors text-[#666666]"
                      title="Close file"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  )}
                </div>
              );
            })
          ) : (
            <div className="flex items-center gap-1.5 px-3 py-1 bg-[#1e1e1e] text-white border-t-2 border-[#007acc] font-mono text-[12px]">
              <span className="text-[#3794ff]">py</span>
              <span>{fileName}</span>
            </div>
          )}

          {/* Plus button next to main.py / tabs */}
          {isCreatingNew ? (
            <form onSubmit={handleCreateNewTabSubmit} className="flex items-center gap-1">
              <input
                type="text"
                autoFocus
                value={newTabName}
                onChange={(e) => setNewTabName(e.target.value)}
                placeholder="new_script.py"
                onBlur={() => handleCreateNewTabSubmit()}
                onKeyDown={(e) => {
                  if (e.key === 'Escape') setIsCreatingNew(false);
                }}
                className="bg-[#1e1e1e] border border-[#007acc] text-white rounded px-2 py-0.5 text-xs font-mono outline-none w-28"
              />
            </form>
          ) : (
            <button
              id="btn-add-file-tab"
              onClick={() => setIsCreatingNew(true)}
              className="flex items-center justify-center p-1 hover:bg-[#333333] text-[#aaaaaa] hover:text-emerald-400 rounded transition-all font-semibold ml-1 bg-[#252526] border border-[#3c3c3c]"
              title="Create New Python File (+)"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          )}

          <span className="hidden sm:inline-block text-[10px] text-[#777777] uppercase font-semibold ml-2">
            Python 3.11 WASM
          </span>
        </div>

        {/* Right: Controls */}
        <div className="flex items-center gap-1 shrink-0">
          {/* Zoom controls */}
          <button
            onClick={() => setFontSize((prev) => Math.min(prev + 2, 28))}
            className="p-1 hover:bg-[#333333] text-[#aaaaaa] hover:text-white rounded transition-colors"
            title="Increase Font Size"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <span className="text-[11px] font-mono w-6 text-center text-[#cccccc]">{fontSize}px</span>
          <button
            onClick={() => setFontSize((prev) => Math.max(prev - 2, 10))}
            className="p-1 hover:bg-[#333333] text-[#aaaaaa] hover:text-white rounded transition-colors"
            title="Decrease Font Size"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>

          <div className="w-px h-3 bg-[#333333] mx-1" />

          {/* Copy Code */}
          <button
            onClick={handleCopy}
            className="flex items-center gap-1 px-2 py-0.5 hover:bg-[#333333] text-[#aaaaaa] hover:text-white rounded transition-colors text-[11px]"
            title="Copy Code to Clipboard"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">{copied ? 'Copied' : 'Copy'}</span>
          </button>
        </div>
      </div>

      {/* Monaco Editor Canvas */}
      <div className="flex-1 relative bg-[#1e1e1e]">
        <Editor
          height="100%"
          defaultLanguage="python"
          language="python"
          value={value}
          theme={theme === 'light' ? 'light' : 'vs-dark'}
          onChange={(val) => onChange(val || '')}
          onMount={handleEditorDidMount}
          options={{
            fontSize: fontSize,
            fontFamily: "'JetBrains Mono', 'Fira Code', Consolas, Monaco, monospace",
            fontLigatures: true,
            minimap: { enabled: true },
            scrollBeyondLastLine: false,
            automaticLayout: true,
            tabSize: 4,
            wordWrap: 'on',
            lineNumbers: 'on',
            renderLineHighlight: 'all',
            padding: { top: 12, bottom: 12 },
            smoothScrolling: true,
            cursorBlinking: 'smooth',
            cursorSmoothCaretAnimation: 'on',
            folding: true,
            suggestOnTriggerCharacters: true,
          }}
          loading={
            <div className="flex items-center justify-center h-full bg-[#1e1e1e] text-[#888888] text-xs font-mono">
              <span>Loading Monaco Python Code Editor...</span>
            </div>
          }
        />
      </div>
    </div>
  );
};

