import React, { useState } from 'react';
import { Package, X, Search, CheckCircle, Download, Loader2, RefreshCw } from 'lucide-react';
import { PythonPackage } from '../types';
import { pyodideRunner } from '../lib/pyodideRunner';

interface PackageManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const PRESET_PACKAGES: PythonPackage[] = [
  {
    name: 'numpy',
    description: 'Fundamental package for scientific computing, arrays, matrices and math functions.',
    status: 'available',
    category: 'Math & Science',
  },
  {
    name: 'pandas',
    description: 'Powerful data structures for data analysis, DataFrames, time series, and manipulation.',
    status: 'available',
    category: 'Data Science',
  },
  {
    name: 'matplotlib',
    description: 'Comprehensive library for creating static, animated, and interactive visual plots.',
    status: 'available',
    category: 'Visualization',
  },
  {
    name: 'scipy',
    description: 'Ecosystem for mathematics, science, signal processing and engineering algorithms.',
    status: 'available',
    category: 'Math & Science',
  },
  {
    name: 'sympy',
    description: 'Python library for symbolic mathematics, computer algebra, and calculus.',
    status: 'available',
    category: 'Math & Science',
  },
  {
    name: 'scikit-learn',
    description: 'Simple and efficient tools for predictive data analysis and machine learning.',
    status: 'available',
    category: 'Data Science',
  },
  {
    name: 'networkx',
    description: 'Software for creating, manipulating, and studying complex graph structures.',
    status: 'available',
    category: 'Utilities',
  },
  {
    name: 'pillow',
    description: 'Python Imaging Library (PIL) fork for image processing and raster graphics.',
    status: 'available',
    category: 'Utilities',
  },
  {
    name: 'regex',
    description: 'Advanced regular expression matching engine superseding built-in re module.',
    status: 'available',
    category: 'Utilities',
  },
  {
    name: 'pytz',
    description: 'World timezone definitions and UTC conversions for Python datetime objects.',
    status: 'available',
    category: 'Utilities',
  },
];

export const PackageManagerModal: React.FC<PackageManagerModalProps> = ({ isOpen, onClose }) => {
  const [packages, setPackages] = useState<PythonPackage[]>(PRESET_PACKAGES);
  const [searchQuery, setSearchQuery] = useState('');
  const [installingName, setInstallingName] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleInstall = async (pkgName: string) => {
    setInstallingName(pkgName);
    setPackages((prev) =>
      prev.map((p) => (p.name === pkgName ? { ...p, status: 'installing' } : p))
    );

    try {
      await pyodideRunner.installPackage(pkgName);
      setPackages((prev) =>
        prev.map((p) => (p.name === pkgName ? { ...p, status: 'installed' } : p))
      );
    } catch (err) {
      setPackages((prev) =>
        prev.map((p) => (p.name === pkgName ? { ...p, status: 'error' } : p))
      );
    } finally {
      setInstallingName(null);
    }
  };

  const filteredPackages = packages.filter(
    (p) =>
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 z-50 font-sans">
      <div className="bg-[#252526] border border-[#3c3c3c] rounded-lg shadow-2xl max-w-2xl w-full flex flex-col max-h-[85vh] overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b border-[#2b2b2b] flex items-center justify-between bg-[#1f1f1f]">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-900/40 border border-amber-700/60 rounded-lg text-amber-400">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-sm text-white">Python Package Manager</h2>
              <p className="text-xs text-[#aaaaaa]">Install pure Python & C-extension WASM packages into Pyodide</p>
            </div>
          </div>

          <button onClick={onClose} className="p-1.5 text-[#aaaaaa] hover:text-white rounded hover:bg-[#333333]">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search bar */}
        <div className="p-4 border-b border-[#2b2b2b] bg-[#252526] flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-[#777777]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search packages (e.g. numpy, pandas, matplotlib)..."
              className="w-full pl-9 pr-4 py-1.5 bg-[#1e1e1e] border border-[#444444] text-white rounded-lg text-xs outline-none focus:border-amber-500 font-mono"
            />
          </div>
        </div>

        {/* Package list */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-[#1e1e1e]">
          {filteredPackages.map((pkg) => (
            <div
              key={pkg.name}
              className="p-3 bg-[#252526] border border-[#333333] hover:border-[#444444] rounded flex items-center justify-between gap-4 transition-all"
            >
              <div className="flex flex-col gap-1 flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-mono font-bold text-sm text-amber-400">{pkg.name}</span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-[#1e1e1e] text-[#aaaaaa] font-medium border border-[#333333]">
                    {pkg.category}
                  </span>
                </div>
                <p className="text-xs text-[#aaaaaa] leading-snug">{pkg.description}</p>
              </div>

              <div>
                {pkg.status === 'installed' ? (
                  <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-medium px-3 py-1.5 bg-emerald-950/40 border border-emerald-800 rounded">
                    <CheckCircle className="w-4 h-4" />
                    <span>Installed</span>
                  </div>
                ) : pkg.status === 'installing' ? (
                  <div className="flex items-center gap-1.5 text-xs text-amber-300 font-medium px-3 py-1.5 bg-amber-950/40 border border-amber-800 rounded animate-pulse">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Downloading...</span>
                  </div>
                ) : (
                  <button
                    onClick={() => handleInstall(pkg.name)}
                    disabled={installingName !== null}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-[#007acc] hover:bg-[#0062a3] text-white font-medium text-xs rounded shadow transition-all disabled:opacity-40"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Install</span>
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Modal Footer */}
        <div className="p-3 border-t border-[#2b2b2b] bg-[#1f1f1f] text-right text-xs text-[#888888]">
          Packages are loaded dynamically from Pyodide CDN with full WebAssembly compilation.
        </div>
      </div>
    </div>
  );
};
