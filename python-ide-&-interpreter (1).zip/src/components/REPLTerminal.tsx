import React, { useState, useRef, useEffect } from 'react';
import { Terminal, Send, Trash2, ArrowUp, ArrowDown, HelpCircle } from 'lucide-react';
import { pyodideRunner } from '../lib/pyodideRunner';

interface REPLHistoryItem {
  id: string;
  command: string;
  result?: string;
  error?: string;
}

export const REPLTerminal: React.FC = () => {
  const [inputCommand, setInputCommand] = useState('');
  const [history, setHistory] = useState<REPLHistoryItem[]>([
    {
      id: 'init-1',
      command: '# Interactive Python 3.11 REPL Shell',
      result: 'Type any Python statement or math expression and press Enter.\nTry: 2 ** 10 or import math; math.factorial(10)',
    },
  ]);
  const [commandHistory, setCommandHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState<number>(-1);
  const [isExecuting, setIsExecuting] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cmd = inputCommand.trim();
    if (!cmd) return;

    setInputCommand('');
    setCommandHistory((prev) => [...prev, cmd]);
    setHistoryIndex(-1);

    const newItemId = String(Date.now());
    setIsExecuting(true);

    try {
      const res = await pyodideRunner.runREPL(cmd);
      setHistory((prev) => [
        ...prev,
        {
          id: newItemId,
          command: cmd,
          result: res,
        },
      ]);
    } catch (err: any) {
      setHistory((prev) => [
        ...prev,
        {
          id: newItemId,
          command: cmd,
          error: err.message || String(err),
        },
      ]);
    } finally {
      setIsExecuting(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (commandHistory.length === 0) return;
      const nextIdx = historyIndex + 1 < commandHistory.length ? historyIndex + 1 : historyIndex;
      setHistoryIndex(nextIdx);
      setInputCommand(commandHistory[commandHistory.length - 1 - nextIdx] || '');
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIndex > 0) {
        const nextIdx = historyIndex - 1;
        setHistoryIndex(nextIdx);
        setInputCommand(commandHistory[commandHistory.length - 1 - nextIdx] || '');
      } else if (historyIndex === 0) {
        setHistoryIndex(-1);
        setInputCommand('');
      }
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#1e1e1e] font-mono text-xs select-text overflow-hidden">
      {/* Shell Header */}
      <div className="h-8 bg-[#252526] border-b border-[#2b2b2b] flex items-center justify-between px-4 select-none shrink-0 text-[#aaaaaa]">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-emerald-400" />
          <span className="font-semibold text-white">Interactive Python Shell (REPL)</span>
          <span className="text-[10px] bg-[#1e1e1e] text-[#888888] px-2 py-0.5 rounded border border-[#333333]">
            Pyodide v0.26.4
          </span>
        </div>

        <button
          onClick={() => setHistory([])}
          className="p-1 hover:bg-[#333333] text-[#aaaaaa] hover:text-rose-400 rounded transition-colors"
          title="Clear REPL History"
        >
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* REPL Logs */}
      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3">
        {history.map((item) => (
          <div key={item.id} className="flex flex-col gap-1">
            <div className="flex items-start gap-2 text-[#3794ff] font-semibold">
              <span className="text-emerald-400 select-none">{'>>>'}</span>
              <span className="whitespace-pre-wrap break-all">{item.command}</span>
            </div>

            {item.result !== undefined && item.result !== '' && (
              <div className="pl-6 text-[#cccccc] whitespace-pre-wrap break-all">
                {item.result}
              </div>
            )}

            {item.error && (
              <div className="pl-6 text-rose-400 whitespace-pre-wrap break-all font-sans bg-rose-950/30 p-2 rounded border border-rose-900/50">
                {item.error}
              </div>
            )}
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* REPL Stdin Line */}
      <form onSubmit={handleSubmit} className="p-3 bg-[#252526] border-t border-[#2b2b2b] flex items-center gap-2 shrink-0">
        <span className="text-emerald-400 font-bold select-none text-sm">&gt;&gt;&gt;</span>
        <input
          ref={inputRef}
          type="text"
          value={inputCommand}
          onChange={(e) => setInputCommand(e.target.value)}
          onKeyDown={handleKeyDown}
          disabled={isExecuting}
          placeholder={isExecuting ? 'Evaluating Python command...' : 'Type Python expression e.g. [x**2 for x in range(5)]'}
          className="flex-1 bg-[#1e1e1e] text-white border border-[#444444] rounded px-3 py-1.5 outline-none focus:border-[#007acc] font-mono text-xs"
        />
        <button
          type="submit"
          disabled={isExecuting || !inputCommand.trim()}
          className="px-3.5 py-1.5 bg-[#007acc] hover:bg-[#0062a3] disabled:opacity-40 text-white font-medium rounded flex items-center gap-1 transition-all"
        >
          <Send className="w-3.5 h-3.5" />
          <span>Eval</span>
        </button>
      </form>
    </div>
  );
};
