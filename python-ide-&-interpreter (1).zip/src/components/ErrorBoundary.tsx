import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw, Code2 } from 'lucide-react';

interface Props {
  children?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
    errorInfo: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, errorInfo: null };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error in React Component:', error, errorInfo);
    this.setState({ errorInfo });
  }

  private handleReload = () => {
    window.location.reload();
  };

  private handleResetState = () => {
    localStorage.clear();
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen w-screen bg-[#1e1e1e] text-[#cccccc] flex flex-col items-center justify-center p-6 font-sans select-none">
          <div className="max-w-xl w-full bg-[#252526] border border-[#3c3c3c] rounded-xl shadow-2xl p-6 flex flex-col items-center text-center gap-4">
            <div className="w-14 h-14 bg-rose-500/10 border border-rose-500/30 rounded-full flex items-center justify-center text-rose-400">
              <AlertTriangle className="w-7 h-7" />
            </div>

            <div className="space-y-1">
              <h1 className="text-xl font-bold text-white">Something Went Wrong</h1>
              <p className="text-xs text-[#aaaaaa]">
                An unexpected UI exception occurred in Python Web Studio.
              </p>
            </div>

            {this.state.error && (
              <div className="w-full bg-[#1e1e1e] border border-[#333333] rounded-lg p-3 text-left font-mono text-xs text-rose-300 overflow-x-auto max-h-40">
                {this.state.error.toString()}
              </div>
            )}

            <div className="flex items-center gap-3 w-full pt-2">
              <button
                onClick={this.handleReload}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-[#007acc] hover:bg-[#0062a3] text-white text-xs font-semibold rounded shadow transition-all"
              >
                <RefreshCw className="w-4 h-4" />
                <span>Reload IDE</span>
              </button>

              <button
                onClick={this.handleResetState}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-[#2d2d2d] hover:bg-[#383838] border border-[#444444] text-[#cccccc] hover:text-white text-xs font-medium rounded transition-all"
              >
                <Code2 className="w-4 h-4" />
                <span>Reset Workspace</span>
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
