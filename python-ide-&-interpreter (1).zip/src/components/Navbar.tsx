import React, { useState } from 'react';
import {
  Play,
  Square,
  Sparkles,
  Package,
  FileCode,
  Download,
  Trash2,
  HelpCircle,
  Sun,
  Moon,
  ChevronDown,
  Terminal,
  Code2,
  Minus,
  Square as SquareIcon,
  X,
  Search,
  Code
} from 'lucide-react';
import { IDETheme, PyodideState, CodeExample } from '../types';
import { PYTHON_EXAMPLES } from '../data/examples';

interface NavbarProps {
  pyodideState: PyodideState;
  onRunCode: () => void;
  onStopExecution: () => void;
  theme: IDETheme;
  onThemeChange: (theme: IDETheme) => void;
  onSelectExample: (example: CodeExample) => void;
  onOpenPackageManager: () => void;
  onOpenShortcuts: () => void;
  isAiDrawerOpen: boolean;
  onToggleAiDrawer: () => void;
  activeTab: 'editor' | 'repl';
  setActiveTab: (tab: 'editor' | 'repl') => void;
  onCreateFile?: (name: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  pyodideState,
  onRunCode,
  onStopExecution,
  theme,
  onThemeChange,
  onSelectExample,
  onOpenPackageManager,
  onOpenShortcuts,
  isAiDrawerOpen,
  onToggleAiDrawer,
  activeTab,
  setActiveTab,
  onCreateFile,
}) => {
  const [activeMenu, setActiveMenu] = useState<string | null>(null);

  return (
    <header className="bg-[#1f1f1f] text-[#cccccc] border-b border-[#2b2b2b] select-none shrink-0 flex flex-col font-sans">
      {/* Top Titlebar & Menu Strip */}
      <div className="h-8 bg-[#1f1f1f] flex items-center justify-between px-3 text-xs border-b border-[#2b2b2b]/60">
        {/* Left: Window Dots & App Logo & Menu Items */}
        <div className="flex items-center gap-3">
          {/* macOS Window Controls */}
          <div className="flex items-center gap-1.5 pr-2">
            <span className="w-3 h-3 rounded-full bg-[#ff5f56] border border-[#e0443e]/40 inline-block" />
            <span className="w-3 h-3 rounded-full bg-[#ffbd2e] border border-[#dea123]/40 inline-block" />
            <span className="w-3 h-3 rounded-full bg-[#27c93f] border border-[#1aab29]/40 inline-block" />
          </div>

          {/* Python Branding Icon */}
          <div className="flex items-center gap-1.5 font-bold text-xs text-white pr-2 border-r border-[#333333]">
            <span className="text-base">🐍</span>
            <span className="hidden sm:inline font-semibold tracking-wide">Python IDE</span>
          </div>

          {/* VS Code Text Menu Options */}
          <div className="hidden md:flex items-center text-[12px] text-[#cccccc] font-normal relative">
            {[
              {
                id: 'file',
                label: 'File',
                items: [
                  { label: 'New Python File (+)', action: () => { if (onCreateFile) onCreateFile(`script_${Date.now().toString().slice(-4)}.py`); setActiveMenu(null); } },
                  { label: 'Load Sample Projects', action: () => { onSelectExample(PYTHON_EXAMPLES[0]); setActiveMenu(null); } },
                  { label: 'Manage Packages (pip)', action: () => { onOpenPackageManager(); setActiveMenu(null); } }
                ]
              },
              {
                id: 'edit',
                label: 'Edit',
                items: [
                  { label: 'Run Active Code', action: () => { onRunCode(); setActiveMenu(null); } },
                  { label: 'Toggle AI Assistant', action: () => { onToggleAiDrawer(); setActiveMenu(null); } }
                ]
              },
              {
                id: 'selection',
                label: 'Selection',
                items: [
                  { label: 'Select All Code (Ctrl+A)', action: () => { setActiveMenu(null); } },
                  { label: 'Format Document', action: () => { setActiveMenu(null); } }
                ]
              },
              {
                id: 'view',
                label: 'View',
                items: [
                  { label: 'Code Editor Mode', action: () => { setActiveTab('editor'); setActiveMenu(null); } },
                  { label: 'Interactive REPL Mode', action: () => { setActiveTab('repl'); setActiveMenu(null); } },
                  { label: 'Toggle Theme', action: () => { onThemeChange(theme === 'vs-dark' ? 'light' : 'vs-dark'); setActiveMenu(null); } }
                ]
              },
              {
                id: 'go',
                label: 'Go',
                items: [
                  { label: 'Switch to Editor', action: () => { setActiveTab('editor'); setActiveMenu(null); } },
                  { label: 'Switch to REPL Terminal', action: () => { setActiveTab('repl'); setActiveMenu(null); } }
                ]
              },
              {
                id: 'run',
                label: 'Run',
                items: [
                  { label: 'Run Python Script (Ctrl+Enter)', action: () => { onRunCode(); setActiveMenu(null); } },
                  { label: 'Stop Execution', action: () => { onStopExecution(); setActiveMenu(null); } }
                ]
              },
              {
                id: 'terminal',
                label: 'Terminal',
                items: [
                  { label: 'Open Interactive REPL', action: () => { setActiveTab('repl'); setActiveMenu(null); } },
                  { label: 'Switch to Code Editor', action: () => { setActiveTab('editor'); setActiveMenu(null); } }
                ]
              },
              {
                id: 'help',
                label: 'Help',
                items: [
                  { label: 'Keyboard Shortcuts (Ctrl+/)', action: () => { onOpenShortcuts(); setActiveMenu(null); } },
                  { label: 'Pyodide WASM Info', action: () => { alert('Python Web Studio uses Pyodide 0.26 WebAssembly to run Python 3.11 in browser.'); setActiveMenu(null); } }
                ]
              }
            ].map((menu) => (
              <div key={menu.id} className="relative">
                <button
                  onClick={() => setActiveMenu(activeMenu === menu.id ? null : menu.id)}
                  className={`px-2 py-0.5 rounded text-[#cccccc] hover:bg-[#2a2d2e] transition-colors ${
                    activeMenu === menu.id ? 'bg-[#2a2d2e] text-white font-medium' : ''
                  }`}
                >
                  {menu.label}
                </button>

                {activeMenu === menu.id && (
                  <>
                    <div className="fixed inset-0 z-40" onClick={() => setActiveMenu(null)} />
                    <div className="absolute left-0 top-full mt-1 w-52 bg-[#252526] border border-[#454545] rounded shadow-2xl py-1 z-50 text-xs">
                      {menu.items.map((item, idx) => (
                        <button
                          key={idx}
                          onClick={item.action}
                          className="w-full text-left px-3 py-1.5 hover:bg-[#04395e] hover:text-white text-[#cccccc] flex items-center justify-between"
                        >
                          <span>{item.label}</span>
                        </button>
                      ))}
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Center: Window Title */}
        <div className="hidden lg:flex items-center gap-2 text-[11px] text-[#888888] font-mono">
          <Code className="w-3.5 h-3.5 text-[#007acc]" />
          <span>Python Web Studio — Pyodide WASM Engine</span>
        </div>

        {/* Right: Quick Controls & Window Actions */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 text-[11px] text-[#aaaaaa]">
            <span
              className={`w-2 h-2 rounded-full ${
                pyodideState.isExecuting
                  ? 'bg-amber-400 animate-ping'
                  : pyodideState.isLoaded
                  ? 'bg-emerald-400'
                  : 'bg-blue-400 animate-pulse'
              }`}
            />
            <span className="hidden xl:inline max-w-28 truncate">{pyodideState.statusMessage}</span>
          </div>

          <div className="w-px h-3 bg-[#333333] mx-1" />

          {/* Theme Toggle */}
          <button
            id="btn-theme-switcher"
            onClick={() => onThemeChange(theme === 'vs-dark' ? 'light' : 'vs-dark')}
            className="p-1 hover:bg-[#2a2d2e] rounded text-[#aaaaaa] hover:text-white transition-colors"
            title={`Switch Theme (Current: ${theme})`}
          >
            {theme === 'vs-dark' ? <Sun className="w-3.5 h-3.5 text-amber-400" /> : <Moon className="w-3.5 h-3.5 text-blue-400" />}
          </button>

          {/* Shortcuts */}
          <button
            id="btn-shortcuts"
            onClick={onOpenShortcuts}
            className="p-1 hover:bg-[#2a2d2e] rounded text-[#aaaaaa] hover:text-white transition-colors"
            title="Keyboard Shortcuts"
          >
            <HelpCircle className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Action Bar */}
      <div className="h-10 bg-[#252526] flex items-center justify-between px-3 gap-2">
        {/* Left: View Tab Switcher (Editor vs REPL) */}
        <div className="flex items-center gap-2">
          <div className="flex bg-[#1e1e1e] p-0.5 rounded border border-[#333333] text-xs">
            <button
              id="tab-btn-editor"
              onClick={() => setActiveTab('editor')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs transition-all ${
                activeTab === 'editor'
                  ? 'bg-[#007acc] text-white font-medium shadow'
                  : 'text-[#888888] hover:text-[#cccccc] hover:bg-[#2a2d2e]'
              }`}
            >
              <Code2 className="w-3.5 h-3.5" />
              <span>Editor</span>
            </button>
            <button
              id="tab-btn-repl"
              onClick={() => setActiveTab('repl')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs transition-all ${
                activeTab === 'repl'
                  ? 'bg-[#007acc] text-white font-medium shadow'
                  : 'text-[#888888] hover:text-[#cccccc] hover:bg-[#2a2d2e]'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>Interactive REPL</span>
            </button>
          </div>

          {/* Run / Stop Button */}
          {pyodideState.isExecuting ? (
            <button
              id="btn-stop-execution"
              onClick={onStopExecution}
              className="flex items-center gap-1.5 px-3 py-1 bg-rose-600 hover:bg-rose-500 text-white font-medium text-xs rounded transition-all animate-pulse shadow"
              title="Stop Python Execution"
            >
              <Square className="w-3.5 h-3.5 fill-current" />
              <span>Stop</span>
            </button>
          ) : (
            <button
              id="btn-run-code"
              onClick={onRunCode}
              disabled={pyodideState.isLoading}
              className={`flex items-center gap-1.5 px-3.5 py-1 font-medium text-xs rounded shadow transition-all ${
                pyodideState.isLoading
                  ? 'bg-[#333333] text-[#777777] cursor-not-allowed'
                  : 'bg-[#2ea043] hover:bg-[#3fb950] text-white active:scale-95'
              }`}
              title="Run Python Code (Ctrl + Enter)"
            >
              <Play className="w-3.5 h-3.5 fill-current text-white" />
              <span>Run Code</span>
            </button>
          )}
        </div>

        {/* Center/Right: Feature Buttons */}
        <div className="flex items-center gap-2">
          {/* Code Examples Dropdown */}
          <div className="relative group">
            <button
              id="dropdown-examples-btn"
              className="flex items-center gap-1.5 px-2.5 py-1 bg-[#2d2d2d] hover:bg-[#383838] border border-[#3c3c3c] text-xs text-[#cccccc] rounded transition-all"
            >
              <FileCode className="w-3.5 h-3.5 text-[#3794ff]" />
              <span className="hidden sm:inline">Examples</span>
              <ChevronDown className="w-3 h-3 text-[#888888]" />
            </button>

            <div className="absolute top-full right-0 mt-1 w-64 bg-[#252526] border border-[#454545] rounded-md shadow-2xl py-1 hidden group-hover:block z-50 max-h-96 overflow-y-auto">
              <div className="px-3 py-1.5 text-[10px] font-semibold text-[#888888] uppercase tracking-wider border-b border-[#333333]">
                Sample Python Code
              </div>
              {PYTHON_EXAMPLES.map((ex) => (
                <button
                  key={ex.id}
                  onClick={() => onSelectExample(ex)}
                  className="w-full text-left px-3 py-2 text-xs hover:bg-[#04395e] hover:text-white transition-colors flex flex-col gap-0.5"
                >
                  <div className="flex items-center justify-between font-medium text-[#cccccc]">
                    <span>{ex.title}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#1e1e1e] text-[#888888] border border-[#333333]">
                      {ex.category}
                    </span>
                  </div>
                  <span className="text-[11px] text-[#888888] line-clamp-1">{ex.description}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Package Manager */}
          <button
            id="btn-packages"
            onClick={onOpenPackageManager}
            className="flex items-center gap-1.5 px-2.5 py-1 bg-[#2d2d2d] hover:bg-[#383838] border border-[#3c3c3c] text-xs text-[#cccccc] rounded transition-all"
            title="Python Package Manager (pip / Pyodide)"
          >
            <Package className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden md:inline">Packages</span>
          </button>

          {/* Gemini AI Assistant Drawer Button */}
          <button
            id="btn-ai-assistant"
            onClick={onToggleAiDrawer}
            className={`flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded border transition-all ${
              isAiDrawerOpen
                ? 'bg-purple-600 text-white border-purple-500 shadow-lg shadow-purple-900/30'
                : 'bg-purple-950/40 hover:bg-purple-900/50 text-purple-300 border-purple-800/80'
            }`}
            title="Toggle Gemini AI Python Assistant"
          >
            <Sparkles className="w-3.5 h-3.5 text-purple-300 animate-pulse" />
            <span className="hidden sm:inline">AI Assistant</span>
          </button>
        </div>
      </div>
    </header>
  );
};

