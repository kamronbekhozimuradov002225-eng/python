import React, { useState, useRef } from 'react';
import {
  FileCode,
  Plus,
  Trash2,
  Edit2,
  Download,
  Upload,
  ChevronRight,
  ChevronDown,
  FileText,
  Folder
} from 'lucide-react';
import { PythonFile } from '../types';

interface FileExplorerProps {
  files: PythonFile[];
  activeFileId: string;
  onSelectFile: (id: string) => void;
  onCreateFile: (name: string) => void;
  onDeleteFile: (id: string) => void;
  onRenameFile: (id: string, newName: string) => void;
  onUploadFile: (file: File) => void;
  onDownloadFile: (file: PythonFile) => void;
}

export const FileExplorer: React.FC<FileExplorerProps> = ({
  files,
  activeFileId,
  onSelectFile,
  onCreateFile,
  onDeleteFile,
  onRenameFile,
  onUploadFile,
  onDownloadFile,
}) => {
  const [isCreating, setIsCreating] = useState(false);
  const [newFileName, setNewFileName] = useState('');
  const [editingFileId, setEditingFileId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState('');
  const uploadInputRef = useRef<HTMLInputElement>(null);

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    let name = newFileName.trim();
    if (!name) return;
    if (!name.endsWith('.py')) name += '.py';
    onCreateFile(name);
    setNewFileName('');
    setIsCreating(false);
  };

  const handleRenameSubmit = (id: string) => {
    let name = editingName.trim();
    if (name) {
      if (!name.endsWith('.py')) name += '.py';
      onRenameFile(id, name);
    }
    setEditingFileId(null);
  };

  const handleFileUploadChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onUploadFile(e.target.files[0]);
    }
  };

  return (
    <aside className="w-56 bg-[#252526] border-r border-[#2b2b2b] flex flex-col h-full text-[#cccccc] select-none shrink-0 font-sans">
      {/* Folder Header */}
      <div className="p-2.5 border-b border-[#2b2b2b] flex items-center justify-between text-[11px] font-bold text-[#aaaaaa] uppercase tracking-wider bg-[#1f1f1f]">
        <div className="flex items-center gap-1.5 text-white">
          <Folder className="w-3.5 h-3.5 text-amber-400 fill-amber-400/20" />
          <span>EXPLORER: WORKSPACE</span>
        </div>

        <div className="flex items-center gap-1">
          <button
            id="btn-add-file"
            onClick={() => setIsCreating(true)}
            className="p-1 hover:bg-[#2a2d2e] text-[#aaaaaa] hover:text-white rounded transition-colors"
            title="New Python File"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
          <button
            id="btn-upload-file"
            onClick={() => uploadInputRef.current?.click()}
            className="p-1 hover:bg-[#2a2d2e] text-[#aaaaaa] hover:text-white rounded transition-colors"
            title="Upload .py File"
          >
            <Upload className="w-3.5 h-3.5" />
          </button>
          <input
            type="file"
            ref={uploadInputRef}
            onChange={handleFileUploadChange}
            accept=".py,.txt"
            className="hidden"
          />
        </div>
      </div>

      {/* New File Inline Form */}
      {isCreating && (
        <form onSubmit={handleCreateSubmit} className="p-2 border-b border-[#2b2b2b] bg-[#1e1e1e]">
          <div className="flex items-center gap-1.5 bg-[#2d2d2d] border border-[#007acc] rounded px-2 py-1">
            <FileCode className="w-3.5 h-3.5 text-[#3794ff] shrink-0" />
            <input
              type="text"
              autoFocus
              value={newFileName}
              onChange={(e) => setNewFileName(e.target.value)}
              placeholder="filename.py"
              className="bg-transparent text-xs text-white outline-none w-full font-mono"
              onBlur={() => {
                if (!newFileName.trim()) setIsCreating(false);
              }}
            />
          </div>
        </form>
      )}

      {/* File List */}
      <div className="flex-1 overflow-y-auto py-1">
        {files.map((file) => {
          const isActive = file.id === activeFileId;
          const isEditing = file.id === editingFileId;

          return (
            <div
              key={file.id}
              className={`group flex items-center justify-between px-3 py-1.5 text-xs transition-colors cursor-pointer ${
                isActive
                  ? 'bg-[#37373d] text-white font-medium border-l-2 border-[#007acc]'
                  : 'hover:bg-[#2a2d2e] text-[#aaaaaa] hover:text-[#cccccc]'
              }`}
              onClick={() => onSelectFile(file.id)}
            >
              <div className="flex items-center gap-2 truncate min-w-0 flex-1 font-mono text-[12px]">
                <FileCode className={`w-4 h-4 shrink-0 ${isActive ? 'text-[#3794ff]' : 'text-[#888888]'}`} />
                
                {isEditing ? (
                  <input
                    type="text"
                    autoFocus
                    value={editingName}
                    onChange={(e) => setEditingName(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleRenameSubmit(file.id);
                      if (e.key === 'Escape') setEditingFileId(null);
                    }}
                    onBlur={() => handleRenameSubmit(file.id)}
                    className="bg-[#1e1e1e] border border-[#007acc] px-1 text-xs text-white rounded outline-none w-full"
                  />
                ) : (
                  <span className="truncate">{file.name}</span>
                )}
              </div>

              {/* Action buttons on hover */}
              {!isEditing && (
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setEditingFileId(file.id);
                      setEditingName(file.name);
                    }}
                    className="p-1 hover:bg-[#383838] text-[#aaaaaa] hover:text-white rounded"
                    title="Rename"
                  >
                    <Edit2 className="w-3 h-3" />
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDownloadFile(file);
                    }}
                    className="p-1 hover:bg-[#383838] text-[#aaaaaa] hover:text-white rounded"
                    title="Download .py file"
                  >
                    <Download className="w-3 h-3" />
                  </button>
                  {files.length > 1 && !file.isMain && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteFile(file.id);
                      }}
                      className="p-1 hover:bg-[#383838] text-rose-400 hover:text-rose-300 rounded"
                      title="Delete file"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Footer Info */}
      <div className="p-2.5 border-t border-[#2b2b2b] text-[11px] text-[#888888] flex flex-col gap-1 bg-[#1f1f1f]">
        <div className="flex items-center justify-between font-mono">
          <span>Files: {files.length}</span>
          <span className="text-emerald-400 font-semibold">Pyodide 3.11</span>
        </div>
      </div>
    </aside>
  );
};
