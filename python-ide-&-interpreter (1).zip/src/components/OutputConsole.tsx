import React, { useState, useEffect, useRef } from 'react';
import {
  Terminal,
  Trash2,
  Image as ImageIcon,
  Send,
  Clock,
  Download,
  AlertCircle,
  CheckCircle2,
  Maximize2,
  Minimize2
} from 'lucide-react';
import { ConsoleOutput, StdinRequest } from '../types';

interface OutputConsoleProps {
  outputs: ConsoleOutput[];
  onClearOutputs: () => void;
  stdinRequest: StdinRequest | null;
  onSendStdin: (input: string) => void;
  executionTimeMs: number | null;
  isExecuting: boolean;
}

export const OutputConsole: React.FC<OutputConsoleProps> = ({
  outputs,
  onClearOutputs,
  stdinRequest,
  onSendStdin,
  executionTimeMs,
  isExecuting,
}) => {
  const [activeConsoleTab, setActiveConsoleTab] = useState<'terminal' | 'plots'>('terminal');
  const [stdinInputValue, setStdinInputValue] = useState('');
  const [isMaximized, setIsMaximized] = useState(false);
  const logsEndRef = useRef<HTMLDivElement>(null);

  // Auto-switch to plots tab if matplotlib plot output received
  useEffect(() => {
    const hasPlots = outputs.some((o) => o.type === 'matplotlib');
    if (hasPlots && activeConsoleTab !== 'plots') {
      setActiveConsoleTab('plots');
    }
  }, [outputs]);

  // Auto scroll to bottom on new output
  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [outputs, stdinRequest]);

  const handleStdinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!stdinRequest) return;
    onSendStdin(stdinInputValue);
    setStdinInputValue('');
  };

  const handleDownloadLogs = () => {
    const textContent = outputs.map((o) => `[${o.timestamp}] [${o.type.toUpperCase()}] ${o.text}`).join('\n');
    const blob = new Blob([textContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `python_output_${Date.now()}.log`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const plotOutputs = outputs.filter((o) => o.type === 'matplotlib' && o.imageData);

  return (
    <div
      className={`bg-[#1e1e1e] border-t border-[#2b2b2b] flex flex-col font-mono text-xs select-text transition-all duration-200 ${
        isMaximized ? 'h-full flex-1' : 'h-64 sm:h-72'
      }`}
    >
      {/* Console Tab & Action Header */}
      <div className="h-8 bg-[#252526] border-b border-[#2b2b2b] flex items-center justify-between px-3 select-none shrink-0">
        <div className="flex items-center gap-1 font-sans text-xs">
          <button
            id="tab-btn-console-terminal"
            onClick={() => setActiveConsoleTab('terminal')}
            className={`flex items-center gap-1.5 px-3 py-1 text-[11px] font-bold tracking-wider uppercase transition-colors border-b-2 ${
              activeConsoleTab === 'terminal'
                ? 'bg-[#1e1e1e] text-white border-[#007acc]'
                : 'text-[#888888] hover:text-[#cccccc] border-transparent'
            }`}
          >
            <Terminal className="w-3.5 h-3.5 text-emerald-400" />
            <span>TERMINAL</span>
            {outputs.length > 0 && (
              <span className="px-1.5 py-0.2 text-[10px] bg-[#333333] text-[#cccccc] rounded-full font-normal">
                {outputs.length}
              </span>
            )}
          </button>

          <button
            id="tab-btn-console-plots"
            onClick={() => setActiveConsoleTab('plots')}
            className={`flex items-center gap-1.5 px-3 py-1 text-[11px] font-bold tracking-wider uppercase transition-colors border-b-2 ${
              activeConsoleTab === 'plots'
                ? 'bg-[#1e1e1e] text-white border-[#007acc]'
                : 'text-[#888888] hover:text-[#cccccc] border-transparent'
            }`}
          >
            <ImageIcon className="w-3.5 h-3.5 text-[#3794ff]" />
            <span>PLOTS & GRAPHICS</span>
            {plotOutputs.length > 0 && (
              <span className="px-1.5 py-0.2 text-[10px] bg-[#007acc] text-white rounded-full font-normal">
                {plotOutputs.length}
              </span>
            )}
          </button>
        </div>

        {/* Execution Timer & Controls */}
        <div className="flex items-center gap-2">
          {executionTimeMs !== null && !isExecuting && (
            <div className="flex items-center gap-1 text-[11px] text-emerald-400 bg-emerald-950/40 border border-emerald-800/60 px-2 py-0.5 rounded">
              <Clock className="w-3 h-3" />
              <span>{executionTimeMs} ms</span>
            </div>
          )}

          {isExecuting && (
            <div className="flex items-center gap-1.5 text-[11px] text-amber-400 bg-amber-950/40 border border-amber-800/60 px-2 py-0.5 rounded">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
              <span>Running...</span>
            </div>
          )}

          <button
            id="btn-download-logs"
            onClick={handleDownloadLogs}
            disabled={outputs.length === 0}
            className="p-1 hover:bg-[#333333] text-[#aaaaaa] hover:text-white rounded disabled:opacity-40"
            title="Download Logs"
          >
            <Download className="w-3.5 h-3.5" />
          </button>

          <button
            id="btn-clear-console"
            onClick={onClearOutputs}
            disabled={outputs.length === 0}
            className="p-1 hover:bg-[#333333] text-[#aaaaaa] hover:text-rose-400 rounded disabled:opacity-40"
            title="Clear Console Output"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>

          <button
            id="btn-maximize-console"
            onClick={() => setIsMaximized(!isMaximized)}
            className="p-1 hover:bg-[#333333] text-[#aaaaaa] hover:text-white rounded"
            title={isMaximized ? 'Restore Console Size' : 'Maximize Console'}
          >
            {isMaximized ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Terminal Tab View */}
      {activeConsoleTab === 'terminal' && (
        <div className="flex-1 overflow-y-auto p-3 flex flex-col gap-1 bg-[#1e1e1e] text-[#cccccc] leading-relaxed font-mono">
          {outputs.length === 0 && !stdinRequest && (
            <div className="flex-1 flex flex-col items-center justify-center text-[#666666] gap-2 my-8">
              <Terminal className="w-8 h-8 stroke-1 text-[#444444]" />
              <p className="text-xs text-[#777777] font-sans">
                Console output will appear here after running your Python code.
              </p>
            </div>
          )}

          {outputs.map((out) => {
            if (out.type === 'stderr') {
              return (
                <div key={out.id} className="text-rose-400 whitespace-pre-wrap break-words bg-rose-950/20 p-2 rounded border border-rose-900/40 my-0.5">
                  <div className="flex items-center gap-1.5 text-[10px] text-rose-500 font-semibold uppercase mb-1">
                    <AlertCircle className="w-3 h-3" />
                    <span>Python Runtime Traceback</span>
                  </div>
                  {out.text}
                </div>
              );
            }

            if (out.type === 'system') {
              return (
                <div key={out.id} className="text-[#3794ff] text-[11px] py-0.5 font-sans border-b border-[#2b2b2b] flex items-center justify-between">
                  <span>{out.text}</span>
                  <span className="text-[#666666] text-[10px]">{out.timestamp}</span>
                </div>
              );
            }

            if (out.type === 'input-prompt') {
              return (
                <div key={out.id} className="text-amber-300 font-semibold py-0.5">
                  {out.text}
                </div>
              );
            }

            if (out.type === 'input-result') {
              return (
                <div key={out.id} className="text-emerald-400 font-medium py-0.5">
                  &gt; {out.text}
                </div>
              );
            }

            if (out.type === 'matplotlib') {
              return (
                <div key={out.id} className="my-2 p-2 bg-[#252526] rounded border border-[#333333]">
                  <div className="text-[#3794ff] font-sans text-xs mb-2 flex items-center gap-1.5">
                    <ImageIcon className="w-3.5 h-3.5" />
                    <span>{out.text}</span>
                  </div>
                  {out.imageData && (
                    <img
                      src={out.imageData}
                      alt="Matplotlib generated plot"
                      className="max-w-full h-auto rounded border border-[#444444] shadow-md bg-white p-1"
                    />
                  )}
                </div>
              );
            }

            // Standard stdout
            return (
              <div key={out.id} className="text-[#cccccc] whitespace-pre-wrap break-words font-mono py-0.5">
                {out.text}
              </div>
            );
          })}

          {/* Interactive Stdin Form when Python input() is requested */}
          {stdinRequest && (
            <form onSubmit={handleStdinSubmit} className="mt-2 p-2 bg-amber-950/30 border border-amber-500/50 rounded flex items-center gap-2">
              <span className="text-amber-400 font-bold shrink-0">{stdinRequest.prompt || 'input: '}</span>
              <input
                type="text"
                autoFocus
                value={stdinInputValue}
                onChange={(e) => setStdinInputValue(e.target.value)}
                placeholder="Type your input and press Enter..."
                className="flex-1 bg-[#1e1e1e] text-amber-200 border border-[#444444] rounded px-2.5 py-1 text-xs outline-none focus:border-amber-400"
              />
              <button
                type="submit"
                className="px-3 py-1 bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold rounded flex items-center gap-1 shadow"
              >
                <Send className="w-3 h-3" />
                <span>Submit Stdin</span>
              </button>
            </form>
          )}

          <div ref={logsEndRef} />
        </div>
      )}

      {/* Plots Tab View */}
      {activeConsoleTab === 'plots' && (
        <div className="flex-1 overflow-y-auto p-4 bg-[#1e1e1e] flex flex-col items-center justify-center gap-4">
          {plotOutputs.length === 0 ? (
            <div className="text-center text-[#666666] space-y-2 my-8 font-sans">
              <ImageIcon className="w-10 h-10 mx-auto text-[#444444] stroke-1" />
              <p className="text-xs">No generated plots yet.</p>
              <p className="text-[11px] text-[#777777] max-w-sm">
                Run code using Matplotlib or Turtle graphics (e.g. <code className="text-[#3794ff] font-mono">plt.show()</code>) to view rendered charts here!
              </p>
            </div>
          ) : (
            plotOutputs.map((plot) => (
              <div key={plot.id} className="bg-white p-3 rounded-lg shadow-xl border border-[#444444] max-w-2xl w-full">
                <div className="text-slate-800 font-sans font-semibold text-xs mb-2 flex items-center justify-between border-b pb-1">
                  <span>📊 Matplotlib Rendered Plot</span>
                  <span className="text-[10px] text-slate-500">{plot.timestamp}</span>
                </div>
                <img
                  src={plot.imageData}
                  alt="Matplotlib Plot"
                  className="w-full h-auto rounded"
                />
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};
