import React from 'react';
import { HelpCircle, X, Keyboard } from 'lucide-react';

interface ShortcutsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ShortcutsModal: React.FC<ShortcutsModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const shortcuts = [
    { key: 'Ctrl + Enter', desc: 'Run Python Code' },
    { key: 'Ctrl + S', desc: 'Download current .py script' },
    { key: 'Ctrl + F', desc: 'Find & Replace in Monaco Code Editor' },
    { key: 'Tab', desc: 'Indent selection 4 spaces (PEP 8)' },
    { key: 'Shift + Tab', desc: 'Outdent selection' },
    { key: 'Up Arrow / Down Arrow', desc: 'Navigate command history in REPL' },
  ];

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 z-50 font-sans">
      <div className="bg-[#252526] border border-[#3c3c3c] rounded-lg shadow-2xl max-w-md w-full overflow-hidden">
        <div className="p-4 border-b border-[#2b2b2b] flex items-center justify-between bg-[#1f1f1f]">
          <div className="flex items-center gap-2">
            <Keyboard className="w-5 h-5 text-[#3794ff]" />
            <h2 className="font-bold text-sm text-white">Keyboard Shortcuts</h2>
          </div>
          <button onClick={onClose} className="p-1 text-[#aaaaaa] hover:text-white rounded hover:bg-[#333333]">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 space-y-2 text-xs bg-[#1e1e1e]">
          {shortcuts.map((sc) => (
            <div key={sc.key} className="flex items-center justify-between py-1.5 border-b border-[#2b2b2b]">
              <span className="text-[#cccccc] font-medium">{sc.desc}</span>
              <kbd className="px-2 py-1 bg-[#252526] border border-[#444444] rounded text-[11px] font-mono text-amber-300 font-semibold shadow-inner">
                {sc.key}
              </kbd>
            </div>
          ))}
        </div>

        <div className="p-3 border-t border-[#2b2b2b] bg-[#1f1f1f] text-center text-[11px] text-[#888888]">
          Monaco Editor supports standard VS Code keybindings & multi-cursor editing!
        </div>
      </div>
    </div>
  );
};
